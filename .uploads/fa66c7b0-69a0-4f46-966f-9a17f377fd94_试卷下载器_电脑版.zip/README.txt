试卷下载器 - 电脑版打包说明
============================

【这是什么】
把手机 App 里的试卷批量下载到电脑, 每份试卷独立文件夹,
可一键合成 PDF 直接打印。仅限个人账号自用, 请勿外传/二次分发。

【第一次使用, 三步走】

第 1 步: 安装 Python (只装一次)
  1. 打开 https://www.python.org/downloads/ 下载安装包
  2. 安装时【务必勾选】底部的 "Add Python to PATH"
  3. 装完即可, 以后不用再装

第 2 步: 双击 build.bat
  等它自动装依赖并打包, 大约 1-2 分钟。
  成功后 dist 文件夹里会出现 paper_batch.exe

第 3 步: 拿到 token (只第一次需要)
  1. 手机装 ProxyPin, 开启 HTTPS 抓包
  2. 打开功夫豆 App, 随便进一次试卷列表
  3. ProxyPin 里找 papers/list 请求 -> 请求头
  4. 复制 Authorization 的值 (Token token=eyJ... 或只复制 eyJ 那段)
  5. 双击 paper_batch.exe, 粘贴回车
     (会保存在 exe 同目录 token.txt, 以后不用再贴)

【日常使用】
双击 paper_batch.exe, 按菜单数字操作:
  1 = 按条件批量下载 (年级/科目/年份/名校市重点)
  2 = 按名字搜索并下载 (像搜索引擎一样)
  3 = 按试卷 ID 下载
  4 = 已下载的试卷合成 PDF
下载好的试卷在 exe 同目录的 papers\ 文件夹里。

【常见问题】
- 提示 token 过期 / 401: 重新抓包拿新 token, 删掉 token.txt 重开程序
- 提示会员拦截(50000): 该内容需要 App 内会员, 有会员的账号才抓得到
- 双击 exe 闪退: 在 cmd 里拖入 exe 回车运行, 看具体报错
- 想换图标: build.bat 里 PyInstaller 那行加 --icon=图标.ico

文件清单:
  paper_batch_pc.py  程序源码
  build.bat          一键打包脚本
  requirements.txt   依赖列表 (打包时自动装, 仅供参考)
